from Login.Login import Login   

Login()