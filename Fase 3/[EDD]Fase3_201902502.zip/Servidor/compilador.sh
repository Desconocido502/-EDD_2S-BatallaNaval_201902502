g++ -std=c++11 -o main main.cpp
chmod +x ./main
./main